package edu.vt.cs5254.multiquiz

import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import edu.vt.cs5254.multiquiz.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    // Name: Joel Hipkins
    // PID: joel5


    private lateinit var binding: ActivityMainBinding



   private val vm: QuizViewModel by viewModels()

    private lateinit var buttonList: List<Button>

//create a launcher for summartactivity (includes a lambda called when SummaryActivity ends)
    private val summaryLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()

    ) { result ->
    Log.w("!!! MainActivity !!!", "got result from summary: $result")
    if (result.resultCode == RESULT_OK
        && true == result.data?.getBooleanExtra(EXTRA_RESEST_ALL, false)) {
        vm.resetAll()

} else {
    vm.nextQuestion()
    }
updateView(true)
}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        buttonList = listOf(
            binding.answer0Button,
            binding.answer1Button,
            binding.answer2Button,
            binding.answer3Button,
        )


        binding.hintButton.setOnClickListener {
            vm.answerList.filter { it.isEnabled && !it.isCorrect }
                .random()
                .let {
                    it.isEnabled = false
                    it.isSelected = false

                }
            updateView()
        }


        binding.submitButton.setOnClickListener {
            if (vm.isLastQuestion) {
                val intent = SummaryActivity.newIntent(
                    this,
                    vm.correctAnswers,
                    vm.hintsUsed
                    )
                    summaryLauncher.launch(intent)

            } else {

                vm.nextQuestion()
                updateView(true)

            }
        }

        updateView(true)
    }
    private fun updateView(fullUpdate: Boolean = false){

        if (fullUpdate) {

            binding.questionText.setText(vm.currentQuestionText)

            vm.answerList.zip(buttonList)
                .forEach { (clickedAns, btn) ->
                    btn.setText(clickedAns.textResId)
                    btn.setOnClickListener {
                        vm.answerList.filter { it != clickedAns }
                            .forEach {
                                it.isSelected = false

                            }
                        clickedAns.isSelected = !clickedAns.isSelected
                        updateView(false)
                    }

                }
        }
        vm.answerList.zip(buttonList)
            .forEach { (ans, btn) ->
                btn.isSelected = ans.isSelected
                btn.isEnabled = ans.isEnabled
                btn.updateColor()
            }

        binding.hintButton.isEnabled = vm.answerList.any { it.isEnabled && !it.isCorrect}
        binding.submitButton.isEnabled = vm.answerList.any { it.isSelected }

    }
}



