package edu.vt.cs5254.multiquiz

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import edu.vt.cs5254.multiquiz.databinding.ActivitySummaryBinding

const val EXTRA_RESEST_ALL = "edu.vt.cs5254.multiquiz.reset_all"

private const val EXTRA_CORRECT = "edu.vt.cs5254.multiquiz.correct_answers"
private const val EXTRA_HINTS = "edu.vt.cs5254.multiquiz.hints_used"

class SummaryActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySummaryBinding

    private val vm: SummaryViewModel by viewModels()

    private var correctAnswers = 0
    private var hintsUsed = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySummaryBinding.inflate(layoutInflater)

        setContentView(binding.root)

        binding.resetAllButton.setOnClickListener {
            vm.hasResetAll = true
            correctAnswers = 0
            hintsUsed = 0
            setResult(RESULT_OK, Intent().apply { putExtra(EXTRA_RESEST_ALL, true) })

            updateView()

        }

        if (vm.hasResetAll) {
            correctAnswers = 0
            hintsUsed = 0
            setResult(RESULT_OK, Intent().apply { putExtra(EXTRA_RESEST_ALL, true) })
        } else {

            correctAnswers = intent.getIntExtra(EXTRA_CORRECT, -1)
            hintsUsed = intent.getIntExtra(EXTRA_HINTS, -1)

        }

        updateView()

        //set listener for the reset all buttons

    }

    private fun updateView() {
        binding.correctAnswersCount.text = correctAnswers.toString()
        binding.hintsUsedCount.text = hintsUsed.toString()
        binding.resetAllButton.isEnabled = !vm.hasResetAll
    }

    companion object {
        fun newIntent(
            packageContext: Context,
            correctAnswers: Int,
            hintsUsed: Int
        ): Intent {

            val intent = Intent(packageContext, SummaryActivity::class.java)
            intent.putExtra(EXTRA_CORRECT, correctAnswers)
            intent.putExtra(EXTRA_HINTS, hintsUsed)
            return intent

        }
    }

}