package edu.vt.cs5254.multiquiz

import androidx.lifecycle.ViewModel

class QuizViewModel : ViewModel() {

    private val questionList = listOf(
        Question(R.string.q0, listOf(
            Answer(R.string.q0ans0, true),
            Answer(R.string.q0ans1, false),
            Answer(R.string.q0answer_melbourne, false),
            Answer(R.string.q0ans3, false),

            )),

        Question(R.string.q1, listOf(
            Answer(R.string.q1ans0, false),
            Answer(R.string.q1ans1, true),
            Answer(R.string.q1answer_melbourne, false),
            Answer(R.string.q1ans3, false),

            )),
        Question(R.string.q2, listOf(
            Answer(R.string.q2ans0, false),
            Answer(R.string.q2ans1, false),
            Answer(R.string.q2answer_melbourne, true),
            Answer(R.string.q2ans3, false),

            )),

        Question(R.string.q3, listOf(
            Answer(R.string.q3ans0, false),
            Answer(R.string.q3ans1, false),
            Answer(R.string.q3answer_melbourne, false),
            Answer(R.string.q3ans3, true),

            )),

        )

    private var currentIndex = 0

    val currentQuestionText
        get() = questionList[currentIndex].questionResId
    val answerList
        get() = questionList[currentIndex].answerList

          fun nextQuestion() {
         currentIndex = (currentIndex + 1) % questionList.size
          }

        val isLastQuestion
            get() = currentIndex == questionList.size - 1



fun resetAll() {
    questionList.flatMap { it.answerList }.forEach {
        it.isSelected = false
        it.isEnabled = true
    }
    currentIndex = 0
}

    val correctAnswers
    get() = questionList.flatMap { it.answerList }.count { it.isCorrect && it.isSelected }
val hintsUsed
    get() = questionList.flatMap { it.answerList}.count { !it.isEnabled }

}